<?php
/**
 * The template for displaying 404 pages (not found)
 */

get_header(); ?>

<div class="fwrap">
	<div class="grid-container">
		<div class="page_not_found">
			<h1>404 Page not found !!</h1>
		</div>
	</div>
</div>

<?php get_footer();
